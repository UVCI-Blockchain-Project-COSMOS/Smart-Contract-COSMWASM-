---
title: Chat right text fill
categories:
  - Communications
tags:
  - chat bubble
  - text
  - message
---
